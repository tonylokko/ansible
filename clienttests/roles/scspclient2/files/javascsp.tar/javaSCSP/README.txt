# DISCLAIMER  
# Copyright (c) 2016 by Caringo, Inc. -- All rights reserved
# Caringo Confidential and Proprietary

Introduction:
-------------

jtestCAStor is a tool to measure objects/s and MB/s throughput against CAStor.

the GLOBALS file control the desired test parameters.
All results of the tests will be stored in <workdir>/scriptname/hostname/date/ folder.

The tool supports muttable / immuttable and named streams (no Auth).
The tester is responsible for creating the domain, the tool will automatically create the bucket if needed.

Pre-Requirements:
-----------------

- java 1.6.x , tested with openJDK1.6 / RHEL6 / CentOS 6

OS tested so far, Ubuntu 10.04LTS, RHEL6.7, Debian 6.

If you unpack the jars and replace java -jar castortester.jar with java -cp . castortester
then it will also work with java 1.7 , tested with the sun jre 1.7 on debian 6.

All data is generated from RAM using a NullInputStream and NullOutputStream.
This jar has been built with a modified version of Caringo SDK 5.5

HOWTO:
------
To run this tool simply edit GLOBALS with the CAStor IP addresses and desired object sizes/threads,
then run jtestCAStor.sh

